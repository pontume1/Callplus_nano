package com.luncher.bounjour.ringlerr.activity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

import com.luncher.bounjour.ringlerr.SessionManager;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashMap;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class CouponWeb extends AppCompatActivity {

    private static final int PERMISSIONS_REQUEST = 100;
    double latitude; // latitude
    double longitude; // longitude

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SessionManager session = new SessionManager(getApplicationContext());
        // get user data from session
        HashMap<String, String> user = session.getUserDetails();
        // phone
        String mPhoneNo = user.get(SessionManager.KEY_PHONE);
        String name = user.get(SessionManager.KEY_NAME);
        String mobileNumber = getLastnCharacters(mPhoneNo, 10);
        String offer_id = getIntent().getExtras().getString("offer_id");

        checkLocation();

        WebView webview = new WebView(this);
        WebSettings webSettings = webview.getSettings();
        webSettings.setJavaScriptEnabled(true);
        setContentView(webview);
        String url = "http://www.hoopoun.com/admin/api_v2/mobileRedemption";
        String lat = latitude+"";
        String lon = longitude+"";
        String postData = null;
        try {
            postData = "latitude=" + URLEncoder.encode(lat, "UTF-8") + "&longitude=" + URLEncoder.encode(lon, "UTF-8")
                    + "&offer_id=" + URLEncoder.encode(offer_id, "UTF-8") + "&name=" + URLEncoder.encode(name, "UTF-8")
                    + "&mobileNumber=" + URLEncoder.encode(mobileNumber, "UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        webview.postUrl(url,postData.getBytes());
    }

    private void checkLocation() {

        //Check whether this app has access to the location permission//
        int permission = ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION);

        //If the location permission has been granted, then start the TrackerService//
        if (permission == PackageManager.PERMISSION_GRANTED) {

            //Check whether GPS tracking is enabled//
            LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
            boolean isProviderEnabledGPS = lm != null ? lm.isProviderEnabled(LocationManager.GPS_PROVIDER) : false;
            boolean isProviderEnabledNetwork = lm != null ? lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) : false;
            if (isProviderEnabledNetwork) {

                Location location = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                if (location != null) {
                    latitude = location.getLatitude();
                    longitude = location.getLongitude();
                }

            }

            if (isProviderEnabledGPS) {
                Location location = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (location != null) {
                    latitude = location.getLatitude();
                    longitude = location.getLongitude();
                }
            }
        }else {

            //If the app doesn’t currently have access to the user’s location, then request access//
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    PERMISSIONS_REQUEST);
        }
    }

    public String getLastnCharacters(String inputString,
                                     int subStringLength){
        int length = inputString.length();
        if(length <= subStringLength){
            return inputString;
        }
        int startIndex = length-subStringLength;
        return inputString.substring(startIndex);
    }

    @SuppressLint("MissingPermission")
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[]  grantResults) {

        //If the permission has been granted...//
        if (requestCode == PERMISSIONS_REQUEST && grantResults.length == 1
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

            //Check whether GPS tracking is enabled//
            LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
            boolean isProviderEnabledGPS = lm != null ? lm.isProviderEnabled(LocationManager.GPS_PROVIDER) : false;
            boolean isProviderEnabledNetwork = lm != null ? lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) : false;

            if (isProviderEnabledNetwork) {

                Location location = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                if (location != null) {
                    latitude = location.getLatitude();
                    longitude = location.getLongitude();
                }

            }

            if (isProviderEnabledGPS) {
                Location location = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
                if (location != null) {
                    latitude = location.getLatitude();
                    longitude = location.getLongitude();
                }
            }

        } else {

            //If the user denies the permission request, then display a toast with some more information//
            Toast.makeText(this, "Please enable location services to allow GPS tracking", Toast.LENGTH_SHORT).show();
        }
    }
}
