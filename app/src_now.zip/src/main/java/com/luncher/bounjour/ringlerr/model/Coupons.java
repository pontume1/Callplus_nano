package com.luncher.bounjour.ringlerr.model;

import com.google.firebase.database.IgnoreExtraProperties;

/**
 * Created by santanu on 13/3/18.
 */

@IgnoreExtraProperties
public class Coupons {

    public String name;
    public String store;
    public String description;
    public String address;
    public String offer_id;

    // Default constructor required for calls to
    // DataSnapshot.getValue(User.class)
    public Coupons() {
    }

    public Coupons(String name, String store, String description, String address, String offer_id) {
        this.name = name;
        this.store = store;
        this.description = description;
        this.address = address;
        this.offer_id = offer_id;
    }

    public String getStore() {
        return store;
    }
    public String getDescription() {
        return description;
    }
    public String getName() {
        return name;
    }
    public String getAddress() {
        return address;
    }
    public String getOfferID() {
        return offer_id;
    }

}
