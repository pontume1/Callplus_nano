package com.luncher.bounjour.ringlerr.activity;

/**
 * Created by santanu on 11/11/17.
 */

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.luncher.bounjour.ringlerr.MyDbHelper;
import com.luncher.bounjour.ringlerr.R;
import com.luncher.bounjour.ringlerr.adapter.GroupMemberAdapter;
import com.luncher.bounjour.ringlerr.adapter.ListAdapter;
import com.luncher.bounjour.ringlerr.model.ReminderDetails;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;

public class AddGroup extends AppCompatActivity {

    String message;
    EditText sendMgs;
    Button dialog_save;
    public ListView list;
    public GroupMemberAdapter adapter;

    List<String> phone_no = new ArrayList<>();
    List<String> c_name = new ArrayList<>();
    public ArrayList<ReminderDetails> remDetails = new ArrayList<ReminderDetails>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.create_group);

        list = findViewById(R.id.list);
        adapter = new GroupMemberAdapter(this);
        list.setAdapter(adapter);
//        //ImageView profile_image = findViewById(R.id.profile_image);
//        scheduler_person_text = findViewById(R.id.scheduler_person_text);
//        dialog_contact   = findViewById(R.id.scheduler_person_image);
//        secondary_dialog_contact = findViewById(R.id.scheduler_second_person_image);
//        secondary_scheduler_person_text  = findViewById(R.id.scheduler_second_person_text);
//        dialog_save   = findViewById(R.id.save);
//        sendMgs = findViewById(R.id.scheduler_message);
//
//        MyDbHelper myDbHelper = new MyDbHelper(AddGroup.this, null, 2);
//        ArrayList settings = myDbHelper.getSosSetting();

//        closeButton.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
//                finish();
//            }
//
//        });



        dialog_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                save_settings();
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();

        phone_no = getIntent().getStringArrayListExtra("phone_nos");

        for (int i=0; i<phone_no.size(); i++) {
            String c_no = phone_no.get(i);
            String c_na = getContactName(this, c_no);

            ReminderDetails reminderDetails = new ReminderDetails();
            reminderDetails.name = c_na;
            reminderDetails.code = "1";

            remDetails.add(reminderDetails);
        }

        adapter.notifyDataSetChanged();
    }

    private void save_settings(){


    }

    private void saveIt(){
        message = sendMgs.getText().toString();

        if (message.equals("")) {
            Toast.makeText(AddGroup.this, "Message cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }

        if (phone_no == null) {
            Toast.makeText(AddGroup.this, "Please Select a Contact", Toast.LENGTH_SHORT).show();
            return;
        }

        MyDbHelper myDbHelper = new MyDbHelper(AddGroup.this, null, 12);

        Toast.makeText(AddGroup.this, "Saved", Toast.LENGTH_SHORT).show();
        finish();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

    }


    public static String getContactName(Context context, String phoneNumber) {
        ContentResolver cr = context.getContentResolver();
        Uri uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(phoneNumber));
        Cursor cursor = cr.query(uri, new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME}, null, null, null);
        if (cursor == null) {
            return phoneNumber;
        }
        String contactName = null;
        if(cursor.moveToFirst()) {
            contactName = cursor.getString(cursor.getColumnIndex(ContactsContract.PhoneLookup.DISPLAY_NAME));
        }

        if(!cursor.isClosed()) {
            cursor.close();
        }

        return contactName;
    }

    public String getLastnCharacters(String inputString, int subStringLength){
        int length = inputString.length();
        if(length <= subStringLength){
            return inputString;
        }
        int startIndex = length-subStringLength;
        return inputString.substring(startIndex);
    }
}