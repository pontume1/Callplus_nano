package com.luncher.bounjour.ringlerr.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.luncher.bounjour.ringlerr.R;
import com.luncher.bounjour.ringlerr.activity.AddGroup;
import com.luncher.bounjour.ringlerr.activity.ReminderDetail;

public class GroupMemberAdapter extends BaseAdapter {

    private AddGroup main;
    private Long timestamp;

    public GroupMemberAdapter(AddGroup main)
    {
        this.main = main;
    }

    @Override
    public int getCount() {
        return  main.remDetails.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    static class ViewHolderItem {
        TextView name;
        ImageView status_icon;
        Button button_missed;
    }

    @SuppressLint("InflateParams")
    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        ViewHolderItem holder = new ViewHolderItem();
        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) main.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            assert inflater != null;
            convertView = inflater.inflate(R.layout.reminder_detail_list, null);

            holder.name = convertView.findViewById(R.id.name);
            holder.status_icon = convertView.findViewById(R.id.status_icon);
            holder.button_missed = convertView.findViewById(R.id.button_missed);

            convertView.setTag(holder);
        }
        else
        {
            holder = (ViewHolderItem) convertView.getTag();
        }

        Long tsLong = System.currentTimeMillis();
        holder.name.setText(this.main.remDetails.get(position).name);
        String code = this.main.remDetails.get(position).code;
        holder.button_missed.setVisibility(View.GONE);
        holder.status_icon.setVisibility(View.GONE);

        return convertView;
    }

}
