package com.luncher.bounjour.ringlerr.services;

import android.os.Build;
import android.telecom.Connection;
import android.telecom.ConnectionRequest;
import android.telecom.ConnectionService;
import android.telecom.PhoneAccountHandle;

import androidx.annotation.RequiresApi;

@RequiresApi(api = Build.VERSION_CODES.M)
public class MyConnectionService extends ConnectionService {
    @Override
    public Connection onCreateIncomingConnection(PhoneAccountHandle connectionManagerAccount, final ConnectionRequest request) {
        PhoneAccountHandle accountHandle = request.getAccountHandle();

        return super.onCreateIncomingConnection(connectionManagerAccount, request);
    }
}
