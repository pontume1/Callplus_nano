package com.luncher.bounjour.ringlerr.activity;

import android.os.Bundle;

import com.luncher.bounjour.ringlerr.R;

import androidx.appcompat.app.AppCompatActivity;

public class CouponsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.aboutus);
    }
}
