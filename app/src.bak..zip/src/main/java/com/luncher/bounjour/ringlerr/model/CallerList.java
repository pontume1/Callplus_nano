package com.luncher.bounjour.ringlerr.model;

public class CallerList {

    String name;
    String phone;

    public CallerList(String name, String phone) {
        this.name=name;
        this.phone=phone;

    }

    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

}
