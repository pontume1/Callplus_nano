package com.luncher.bounjour.ringlerr.model;

public class ReminderDetails {
    public String name;
    public String code;
}
