package com.luncher.bounjour.ringlerr;

import android.view.View;

public interface RecyclerViewClickListener {
    public void recyclerViewListClicked(View v, String phone, String name, Boolean is_selected);
}
